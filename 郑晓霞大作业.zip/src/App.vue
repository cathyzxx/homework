<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>


export default {
  name: 'App',
  data:function(){
    return {
      title:"学习vue+mongod+nodejs构建项目后台"
    }
  }
}
</script>

<style>

</style>
