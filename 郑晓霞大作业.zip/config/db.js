module.exports =  {
  mongodb : "mongodb://localhost:27017/album"
}


